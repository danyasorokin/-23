﻿using System;
using UserInteraction;


namespace excercise3
{
    class Program
    {
        static void Main()
        {
            ConsoleInteraction ask = new ConsoleInteraction();
                      
            int number1chislitel = ask.GetValueInt("Введите числитель дроби #1: ");
            int number1znamenatel = ask.GetDenominator("Введите знаменатель дроби #1: ");
            int number2chislitel = ask.GetValueInt("Введите числитель дроби #2: ");
            int number2znamenatel = ask.GetDenominator("Введите знаменатель дроби #2: ");

            NaturalFraction result1 = new NaturalFraction(number1chislitel, number1znamenatel);
            NaturalFraction result2 = new NaturalFraction(number2chislitel, number2znamenatel);
            Console.WriteLine($"\nВведены две дроби: {result1.ConvertToString(false)}, {result2.ConvertToString(false)}");

            bool ansContinue;
            do
            {
                Console.WriteLine("\nВ программе предусмотрены следующие операции с дробями:"
                    + "\n1 - Сложение"
                    + "\n2 - Вычитание"
                    + "\n3 - Умножение"
                    + "\n4 - Деление"
                    + "\n5 - Упрощение"
                    + "\n6 - Вывод в виде десятичной дроби"
                    );
                int ans = ask.GetValueInt("Выберите необходимое действие: ");

                switch (ans)
                {
                    case 1:
                        Console.WriteLine($"\nРезультат сложения: {result1.Add(result2).ConvertToString(true)}");
                        break;
                    case 2:
                        Console.WriteLine($"\nРезультат вычитания: {result1.Substract(result2).ConvertToString(true)}");
                        break;
                    case 3:
                        Console.WriteLine($"\nРезультат умножения: {result1.Multiply(result2).ConvertToString(true)}");
                        break;
                    case 4:
                        Console.WriteLine($"\nРезультат деления: {result1.Devide(result2).ConvertToString(true)}");
                        break;
                    case 5:
                        Console.WriteLine($"\nУпрощенные дроби: {result1.ConvertToString(true)},  {result2.ConvertToString(true)}");
                        break;
                    case 6:
                        Console.WriteLine($"\nУпрощенные дроби: {result1.DecimalFraction.ToString().Replace(',', '.')},  {result2.DecimalFraction.ToString().Replace(',', '.')}");
                        break;
                    default:
                        Console.WriteLine($"Функция с кодом \"{ans}\" отсутствует в программе");
                        break;
                }
                ansContinue = ask.AnsYesNo("Желаете выполнить еще какие-либо действия? (y/n)");
            } while (ansContinue);
        }
    }
}