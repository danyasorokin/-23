﻿using System;
using System.Collections.Generic;
using UserInteraction;



namespace excercise2
{
    class Program
    {
        static void Main()
        {
            double digit;
            double sum = 0;
            List<double> lst = new List<double>();
            ConsoleInteraction ask;

            do
            {
                digit = ask.GetValueDouble("Введите любое число: ");
                if (digit % 2 != 0 && digit > 0)
                {
                    lst.Add(digit);
                    sum += digit;
                }
            } while (digit != 0);
            if (sum > 0)
            {
                Console.WriteLine($"Сумма нечетных положительных чисел: {sum}");
                Console.WriteLine($"Были введены следующие числа: ");
                foreach (double lstItem in lst) Console.WriteLine(lstItem);
            }
            else Console.WriteLine("Вы не ввели ни одно нечетное положительное число");
            Console.ReadLine();
        }
    }
}
