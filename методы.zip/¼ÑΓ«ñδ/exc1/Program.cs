﻿using System;
using UserInteraction;


namespace excercise1
{
    class Program
    {
        static void Main()
        {
            ConsoleInteraction ask = new ConsoleInteraction();
            Double number1realnoe = ask.GetValueDouble("Введите реальную часть комплексного числа #1: ");
            Double number1drobnoe = ask.GetValueDouble("Введите мнимую часть комплексного числа #1: ");
            Double number2realnoe = ask.GetValueDouble("Введите реальную часть комплексного числа #2: ");
            Double number2drobnoe = ask.GetValueDouble("Введите мнимую часть комплексного числа #2: ");

            ComplexClass result1 = new ComplexClass(number1realnoe, number1drobnoe);
            ComplexClass result2 = new ComplexClass(number2realnoe, number2drobnoe);
            Console.WriteLine($"\nВведены два комплексных числа: {result1.ConvertToString()}, {result2.ConvertToString()}");

            bool ansContinue;
            do
            {
                Console.WriteLine("\nВ программе предусмотрены следующие арифметические операции:"
                    + "\n1 - Сложение"
                    + "\n2 - Вычитание"
                    + "\n3 - Умножение"
                    + "\n4 - Деление"
                    );
                int ans = ask.GetValueInt("Выберите необходимое действие: ");

                switch (ans)
                {
                    case 1:
                        Console.WriteLine($"\nРезультат сложения: {result1.Add(result2).ConvertToString()}");
                        break;
                    case 2:
                        Console.WriteLine($"\nРезультат вычитания: {result1.Substract(result2).ConvertToString()}");
                        break;
                    case 3:
                        Console.WriteLine($"\nРезультат умножения: {result1.Multiply(result2).ConvertToString()}");
                        break;
                    case 4:
                        Console.WriteLine($"\nРезультат деления: {result1.Devide(result2).ConvertToString()}");
                        break;
                    default:
                        Console.WriteLine($"Функция с кодом \"{ans}\" отсутствует в программе");
                        break;
                }
                ansContinue = ask.AnsYesNo("Желаете выполнить еще какие-либо действия? (y/n)");
            } while (ansContinue);
        }
    }
}